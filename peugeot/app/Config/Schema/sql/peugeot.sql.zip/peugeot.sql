-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 31, 2012 at 06:20 PM
-- Server version: 5.5.28
-- PHP Version: 5.4.6-1ubuntu1.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `peugeot`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=319 ;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, NULL, '', NULL, 'controllers', 1, 286),
(92, 1, '', NULL, 'Settings', 2, 39),
(115, 1, '', NULL, 'Users', 40, 85),
(179, 1, NULL, NULL, 'Acl', 86, 109),
(180, 179, NULL, NULL, 'AclActions', 87, 100),
(181, 180, NULL, NULL, 'admin_index', 88, 89),
(182, 180, NULL, NULL, 'admin_add', 90, 91),
(183, 180, NULL, NULL, 'admin_edit', 92, 93),
(184, 180, NULL, NULL, 'admin_delete', 94, 95),
(185, 180, NULL, NULL, 'admin_move', 96, 97),
(186, 180, NULL, NULL, 'admin_generate', 98, 99),
(187, 179, NULL, NULL, 'AclPermissions', 101, 108),
(188, 187, NULL, NULL, 'admin_index', 102, 103),
(189, 187, NULL, NULL, 'admin_toggle', 104, 105),
(190, 187, NULL, NULL, 'admin_upgrade', 106, 107),
(191, 1, NULL, NULL, 'Extensions', 110, 149),
(192, 191, NULL, NULL, 'ExtensionsLocales', 111, 122),
(193, 192, NULL, NULL, 'admin_index', 112, 113),
(194, 192, NULL, NULL, 'admin_activate', 114, 115),
(195, 192, NULL, NULL, 'admin_add', 116, 117),
(196, 192, NULL, NULL, 'admin_edit', 118, 119),
(197, 192, NULL, NULL, 'admin_delete', 120, 121),
(198, 191, NULL, NULL, 'ExtensionsPlugins', 123, 134),
(199, 198, NULL, NULL, 'admin_index', 124, 125),
(200, 198, NULL, NULL, 'admin_add', 126, 127),
(201, 198, NULL, NULL, 'admin_delete', 128, 129),
(202, 198, NULL, NULL, 'admin_toggle', 130, 131),
(203, 198, NULL, NULL, 'admin_migrate', 132, 133),
(204, 191, NULL, NULL, 'ExtensionsThemes', 135, 148),
(205, 204, NULL, NULL, 'admin_index', 136, 137),
(206, 204, NULL, NULL, 'admin_activate', 138, 139),
(207, 204, NULL, NULL, 'admin_add', 140, 141),
(208, 204, NULL, NULL, 'admin_editor', 142, 143),
(209, 204, NULL, NULL, 'admin_save', 144, 145),
(210, 204, NULL, NULL, 'admin_delete', 146, 147),
(211, 1, NULL, NULL, 'Migrations', 150, 151),
(212, 1, NULL, NULL, 'Search', 152, 153),
(213, 92, NULL, NULL, 'Languages', 3, 18),
(214, 213, NULL, NULL, 'admin_index', 4, 5),
(215, 213, NULL, NULL, 'admin_add', 6, 7),
(216, 213, NULL, NULL, 'admin_edit', 8, 9),
(217, 213, NULL, NULL, 'admin_delete', 10, 11),
(218, 213, NULL, NULL, 'admin_moveup', 12, 13),
(219, 213, NULL, NULL, 'admin_movedown', 14, 15),
(220, 213, NULL, NULL, 'admin_select', 16, 17),
(221, 92, NULL, NULL, 'Settings', 19, 38),
(222, 221, NULL, NULL, 'admin_dashboard', 20, 21),
(223, 221, NULL, NULL, 'admin_index', 22, 23),
(224, 221, NULL, NULL, 'admin_view', 24, 25),
(225, 221, NULL, NULL, 'admin_add', 26, 27),
(226, 221, NULL, NULL, 'admin_edit', 28, 29),
(227, 221, NULL, NULL, 'admin_delete', 30, 31),
(228, 221, NULL, NULL, 'admin_prefix', 32, 33),
(229, 221, NULL, NULL, 'admin_moveup', 34, 35),
(230, 221, NULL, NULL, 'admin_movedown', 36, 37),
(231, 115, NULL, NULL, 'Roles', 41, 50),
(232, 231, NULL, NULL, 'admin_index', 42, 43),
(233, 231, NULL, NULL, 'admin_add', 44, 45),
(234, 231, NULL, NULL, 'admin_edit', 46, 47),
(235, 231, NULL, NULL, 'admin_delete', 48, 49),
(236, 115, NULL, NULL, 'Users', 51, 84),
(237, 236, NULL, NULL, 'admin_index', 52, 53),
(238, 236, NULL, NULL, 'admin_add', 54, 55),
(239, 236, NULL, NULL, 'admin_edit', 56, 57),
(240, 236, NULL, NULL, 'admin_reset_password', 58, 59),
(241, 236, NULL, NULL, 'admin_delete', 60, 61),
(242, 236, NULL, NULL, 'admin_login', 62, 63),
(243, 236, NULL, NULL, 'admin_logout', 64, 65),
(244, 236, NULL, NULL, 'index', 66, 67),
(245, 236, NULL, NULL, 'add', 68, 69),
(246, 236, NULL, NULL, 'activate', 70, 71),
(247, 236, NULL, NULL, 'edit', 72, 73),
(248, 236, NULL, NULL, 'forgot', 74, 75),
(249, 236, NULL, NULL, 'reset', 76, 77),
(250, 236, NULL, NULL, 'login', 78, 79),
(251, 236, NULL, NULL, 'logout', 80, 81),
(252, 236, NULL, NULL, 'view', 82, 83),
(253, 1, NULL, NULL, 'Emails', 154, 213),
(254, 253, NULL, NULL, 'EmailsQueues', 155, 170),
(255, 254, NULL, NULL, 'admin_index', 156, 157),
(256, 254, NULL, NULL, 'admin_view', 158, 159),
(257, 254, NULL, NULL, 'admin_add', 160, 161),
(258, 254, NULL, NULL, 'admin_edit', 162, 163),
(259, 254, NULL, NULL, 'admin_delete', 164, 165),
(260, 254, NULL, NULL, 'admin_toggle_status', 166, 167),
(261, 254, NULL, NULL, 'send_emails', 168, 169),
(262, 253, NULL, NULL, 'EmailsSenders', 171, 184),
(263, 262, NULL, NULL, 'admin_index', 172, 173),
(264, 262, NULL, NULL, 'admin_view', 174, 175),
(265, 262, NULL, NULL, 'admin_add', 176, 177),
(266, 262, NULL, NULL, 'admin_edit', 178, 179),
(267, 262, NULL, NULL, 'admin_delete', 180, 181),
(268, 262, NULL, NULL, 'admin_toggle_status', 182, 183),
(269, 253, NULL, NULL, 'EmailsTemplates', 185, 200),
(270, 269, NULL, NULL, 'admin_index', 186, 187),
(271, 269, NULL, NULL, 'admin_add', 188, 189),
(272, 269, NULL, NULL, 'admin_edit', 190, 191),
(273, 269, NULL, NULL, 'admin_delete', 192, 193),
(274, 269, NULL, NULL, 'admin_toggle_status', 194, 195),
(275, 269, NULL, NULL, 'admin_moveup', 196, 197),
(276, 269, NULL, NULL, 'admin_movedown', 198, 199),
(277, 253, NULL, NULL, 'EmailsVariables', 201, 212),
(278, 277, NULL, NULL, 'admin_index', 202, 203),
(279, 277, NULL, NULL, 'admin_view', 204, 205),
(280, 277, NULL, NULL, 'admin_add', 206, 207),
(281, 277, NULL, NULL, 'admin_edit', 208, 209),
(282, 277, NULL, NULL, 'admin_delete', 210, 211),
(283, 1, NULL, NULL, 'General', 214, 283),
(284, 283, NULL, NULL, 'Autos', 215, 224),
(285, 284, NULL, NULL, 'admin_index', 216, 217),
(286, 284, NULL, NULL, 'admin_add', 218, 219),
(287, 284, NULL, NULL, 'admin_edit', 220, 221),
(288, 284, NULL, NULL, 'admin_delete', 222, 223),
(289, 283, NULL, NULL, 'Concesionarias', 225, 236),
(290, 289, NULL, NULL, 'admin_index', 226, 227),
(291, 289, NULL, NULL, 'admin_view', 228, 229),
(292, 289, NULL, NULL, 'admin_add', 230, 231),
(293, 289, NULL, NULL, 'admin_edit', 232, 233),
(294, 289, NULL, NULL, 'admin_delete', 234, 235),
(295, 283, NULL, NULL, 'Modelos', 237, 248),
(296, 295, NULL, NULL, 'admin_index', 238, 239),
(297, 295, NULL, NULL, 'admin_view', 240, 241),
(298, 295, NULL, NULL, 'admin_add', 242, 243),
(299, 295, NULL, NULL, 'admin_edit', 244, 245),
(300, 295, NULL, NULL, 'admin_delete', 246, 247),
(301, 283, NULL, NULL, 'Turnos', 249, 262),
(302, 301, NULL, NULL, 'admin_index', 250, 251),
(303, 301, NULL, NULL, 'admin_view', 252, 253),
(304, 301, NULL, NULL, 'admin_add', 254, 255),
(305, 301, NULL, NULL, 'admin_edit', 256, 257),
(306, 301, NULL, NULL, 'admin_delete', 258, 259),
(307, 301, NULL, NULL, 'admin_generar', 260, 261),
(308, 283, NULL, NULL, 'Web', 263, 282),
(309, 308, NULL, NULL, 'index', 264, 265),
(310, 308, NULL, NULL, 'modelo_step2', 266, 267),
(311, 308, NULL, NULL, 'modelo_step3', 268, 269),
(312, 308, NULL, NULL, 'getDays', 270, 271),
(313, 308, NULL, NULL, 'getTurnos', 272, 273),
(314, 308, NULL, NULL, 'getConcesionaria', 274, 275),
(315, 308, NULL, NULL, 'ubicacion_step2', 276, 277),
(316, 308, NULL, NULL, 'ubicacion_step3', 278, 279),
(317, 308, NULL, NULL, 'confirmacion', 280, 281),
(318, 1, NULL, NULL, 'Meta', 284, 285);

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `parent_id`, `model`, `foreign_key`, `alias`, `lft`, `rght`) VALUES
(1, 2, 'Role', 1, 'Role-admin', 3, 6),
(2, 3, 'Role', 2, 'Role-promotora', 2, 9),
(3, NULL, 'Role', 3, 'Role-public', 1, 10),
(4, 1, 'User', 1, 'admin', 4, 5),
(5, 2, 'User', 2, 'promotora', 7, 8);

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_read` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_update` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_delete` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `aros_acos`
--

INSERT INTO `aros_acos` (`id`, `aro_id`, `aco_id`, `_create`, `_read`, `_update`, `_delete`) VALUES
(1, 3, 317, '1', '1', '1', '1'),
(2, 3, 316, '1', '1', '1', '1'),
(3, 3, 315, '1', '1', '1', '1'),
(4, 3, 314, '1', '1', '1', '1'),
(5, 3, 313, '1', '1', '1', '1'),
(6, 3, 312, '1', '1', '1', '1'),
(7, 3, 311, '1', '1', '1', '1'),
(8, 3, 310, '1', '1', '1', '1'),
(9, 3, 309, '1', '1', '1', '1'),
(10, 2, 309, '1', '1', '1', '1'),
(11, 2, 310, '1', '1', '1', '1'),
(12, 2, 302, '1', '1', '1', '1'),
(13, 2, 304, '1', '1', '1', '1'),
(14, 2, 305, '1', '1', '1', '1'),
(15, 2, 306, '1', '1', '1', '1'),
(16, 2, 243, '1', '1', '1', '1'),
(17, 2, 242, '1', '1', '1', '1'),
(18, 2, 241, '-1', '-1', '-1', '-1'),
(19, 2, 240, '1', '1', '1', '1'),
(20, 2, 239, '-1', '-1', '-1', '-1'),
(21, 2, 238, '-1', '-1', '-1', '-1'),
(22, 2, 237, '1', '1', '1', '1'),
(23, 2, 222, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `autos`
--

CREATE TABLE IF NOT EXISTS `autos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `vim` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `patentamiento` bigint(20) unsigned NOT NULL,
  `concesionaria_id` int(11) NOT NULL,
  `modelo_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `autos`
--

INSERT INTO `autos` (`id`, `producto`, `color`, `vim`, `patentamiento`, `concesionaria_id`, `modelo_id`, `status`, `created`, `modified`) VALUES
(1, 'RCZ', 'Azul', 'VF34J5FU8DP000225', 10853972, 1, 1, 1, '2012-12-24 20:04:14', '2012-12-28 23:36:59'),
(2, '508 GT', 'Gris Aluminio', 'VF38D4HLACL019385', 10853973, 1, 2, 1, '2012-12-24 20:06:18', '2012-12-28 23:37:07'),
(3, '508 Feline HDI', 'Blanco', 'VF38DRHHADL002301', 10853976, 2, 3, 1, '2012-12-24 20:06:45', '2012-12-28 23:37:23'),
(4, '3008 Tiptronic', 'Negro', 'VF30U5FMADS004904', 10853977, 2, 4, 1, '2012-12-24 20:07:14', '2012-12-28 23:37:33'),
(5, '3008 Premium Plus Manual', 'Negro', 'VF30U5FV8DS001304', 10853978, 1, 5, 1, '2012-12-24 20:07:51', '2012-12-28 23:37:41'),
(6, '5008 Allure Plus', 'Gris Shark', 'VF30E5FV8DS002650', 10853980, 2, 6, 1, '2012-12-24 20:08:25', '2012-12-28 23:37:51'),
(7, '308 CC', 'Azul', 'VF34B5FV8CS010110', 10853982, 3, 7, 1, '2012-12-24 20:08:46', '2012-12-28 23:38:01'),
(8, '308 GTI', 'Negro', 'VF34C5FU8DS005000', 10853983, 2, 8, 1, '2012-12-24 20:09:12', '2012-12-28 23:38:09'),
(9, '308 GTI', 'Negro', 'VF34C5FU8DS004638', 10853984, 3, 8, 1, '2012-12-24 20:09:37', '2012-12-28 23:38:16'),
(10, '408 Sport', 'Azul', '8AD4D5FMJDG061819', 10853985, 1, 9, 1, '2012-12-24 20:10:22', '2012-12-28 23:38:24'),
(11, '408 Feline Nafta', 'AZUL BOURRASQUE', '8AD4DRFJCDG064725', 10853986, 2, 10, 1, '2012-12-24 20:10:49', '2012-12-28 23:38:35'),
(12, '308 Sport', 'Blanco', '8AD4C5FMJDG057055', 10853989, 3, 11, 1, '2012-12-24 20:11:22', '2012-12-28 23:38:45'),
(13, '308 Feline HDI', 'Gris Aluminio', '8AD4C9HGCDG064441', 10853990, 3, 12, 1, '2012-12-24 20:12:12', '2012-12-28 23:38:53'),
(14, '308 Allure 1.6 C/ Nav', 'Gris Grafito', '8AD4CNFPCDG056169', 10853991, 3, 13, 1, '2012-12-24 20:12:39', '2012-12-28 23:39:01'),
(15, '308 Sport', 'Blanco', '8AD4C5FMJDG062322', 10853989, 2, 11, 1, '2012-12-24 20:15:45', '2012-12-28 23:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `concesionarias`
--

CREATE TABLE IF NOT EXISTS `concesionarias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitud` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longitud` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `concesionarias`
--

INSERT INTO `concesionarias` (`id`, `title`, `latitud`, `longitud`, `status`, `created`, `modified`) VALUES
(1, 'Golf Cariló', '-34.58', '-58.47', 1, '2012-12-24 19:56:03', '2012-12-29 19:55:52'),
(2, 'Stand Pinamar', '-34.58', '-58.46', 1, '2012-12-24 19:56:51', '2012-12-29 19:56:15'),
(3, 'Tennis Ranch', '', '', 1, '2012-12-24 19:57:20', '2012-12-24 19:57:20');

-- --------------------------------------------------------

--
-- Table structure for table `emails_queues`
--

CREATE TABLE IF NOT EXISTS `emails_queues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `emails_sender_id` int(11) NOT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `from` text COLLATE utf8_unicode_ci,
  `to` text COLLATE utf8_unicode_ci,
  `bcc` text COLLATE utf8_unicode_ci,
  `body` text COLLATE utf8_unicode_ci,
  `priority` tinyint(1) DEFAULT '0',
  `sent` tinyint(1) DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `emails_queues`
--

INSERT INTO `emails_queues` (`id`, `emails_sender_id`, `subject`, `from`, `to`, `bcc`, `body`, `priority`, `sent`, `created`, `modified`) VALUES
(1, 1, 'Peugeot - recordatorio Test Drive ', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="418" valign="top">\r\n            <img src="http://localhost/peugeot/img/im_lateral-izq.jpg" width="42" height="418" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeot/img/newsletter/inicial/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Juancito Lopez</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Este es un recordatorio para tu test drive</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Tu turno es el: 405</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="5"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#767676;font-size:14px;text-transform:uppercase;">EL 01/01/2013  de 11:40 a 12:00Hs en Golf Cariló</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e2;font-size:12px;text-transform:uppercase;">* Para realizar tu test drive debes confirmar tu reserva 10 minutos antes del horario del turno, caso contrario es cancelada</span>\r\n                </td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="418" valign="top"><img src="http://localhost/peugeot/img/newsletter/inicial/im_lateral-der.jpg" width="42" height="418" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeot/img/newsletter/inicial/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 1, '2012-12-29 19:31:23', '2012-12-29 19:31:23'),
(2, 1, 'Peugeot - recordatorio Test Drive ', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="418" valign="top">\r\n            <img src="http://localhost/peugeot/img/newsletter/inicial/im_lateral-izq.jpg" width="42" height="418" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeot/img/newsletter/inicial/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Sebastian Regueira</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Este es un recordatorio para tu test drive</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Tu turno es el: 406</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="5"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#767676;font-size:14px;text-transform:uppercase;">EL 01/01/2013  de 12:00 a 12:20Hs en Golf Cariló</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e2;font-size:12px;text-transform:uppercase;">* Para realizar tu test drive debes confirmar tu reserva 10 minutos antes del horario del turno, caso contrario es cancelada</span>\r\n                </td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="418" valign="top"><img src="http://localhost/peugeot/img/newsletter/inicial/im_lateral-der.jpg" width="42" height="418" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeot/img/newsletter/inicial/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 1, '2012-12-29 19:35:24', '2012-12-29 19:35:24'),
(3, 1, 'Peugeot - Fin Test Drive', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test Drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="258" valign="top">\r\n            <img src="http://localhost/peugeot/img/im_lateral-izq.jpg" width="42" height="258" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeot/img/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Hola pru</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Gracias por vivir la experiencia Peugeot</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="10"></td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="258" valign="top"><img src="http://localhost/peugeot/img/im_lateral-der.jpg" width="42" height="258" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeot/img/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 1, '2012-12-29 19:46:18', '2012-12-29 19:46:18'),
(4, 1, 'Peugeot - Fin Test Drive', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test Drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="258" valign="top">\r\n            <img src="http://localhost/peugeot/img/newsletter/final/im_lateral-izq.jpg" width="42" height="258" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeot/img/newsletter/final/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Hola juancito</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Gracias por vivir la experiencia Peugeot</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="10"></td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="258" valign="top"><img src="http://localhost/peugeot/img/newsletter/final/im_lateral-der.jpg" width="42" height="258" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeot/img/newsletter/final/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 1, '2012-12-29 19:50:40', '2012-12-29 19:50:40'),
(5, 1, 'Peugeot - recordatorio Test Drive ', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="418" valign="top">\r\n            <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/inicial/im_lateral-izq.jpg" width="42" height="418" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/inicial/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">seeeeebbaaaaa</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Este es un recordatorio para tu test drive</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Tu turno es el: 407</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="5"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#767676;font-size:14px;text-transform:uppercase;">EL 01/01/2013  de 12:20 a 12:40Hs en Golf Cariló</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e2;font-size:12px;text-transform:uppercase;">* Para realizar tu test drive debes confirmar tu reserva 10 minutos antes del horario del turno, caso contrario es cancelada</span>\r\n                </td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="418" valign="top"><img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/inicial/im_lateral-der.jpg" width="42" height="418" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/inicial/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 0, '2012-12-31 17:21:03', '2012-12-31 17:21:03'),
(6, 1, 'Peugeot - Fin Test Drive', NULL, 'regueira@gmail.com', NULL, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test Drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="258" valign="top">\r\n            <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/final/im_lateral-izq.jpg" width="42" height="258" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/final/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Hola juancito</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Gracias por vivir la experiencia Peugeot</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="10"></td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="258" valign="top"><img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/final/im_lateral-der.jpg" width="42" height="258" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="http://localhost/peugeotIntegracion/peugeot/img/newsletter/final/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 0, 0, '2012-12-31 17:58:38', '2012-12-31 17:58:38');

-- --------------------------------------------------------

--
-- Table structure for table `emails_senders`
--

CREATE TABLE IF NOT EXISTS `emails_senders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `delivery` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `port` int(11) NOT NULL,
  `timeout` int(11) NOT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `emails_senders`
--

INSERT INTO `emails_senders` (`id`, `title`, `email`, `delivery`, `port`, `timeout`, `host`, `username`, `password`, `status`, `created`, `modified`) VALUES
(1, 'Peugeot', 'regueira@gmail.com', 'Smtp', 465, 30, 'ssl://smtp.gmail.com', 'regueira@gmail.com', '123123', 1, '2012-07-25 19:35:39', '2012-12-29 20:00:05');

-- --------------------------------------------------------

--
-- Table structure for table `emails_templates`
--

CREATE TABLE IF NOT EXISTS `emails_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` text COLLATE utf8_unicode_ci,
  `body` text COLLATE utf8_unicode_ci,
  `weight` tinyint(4) DEFAULT NULL,
  `emails_sender_id` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `emails_templates`
--

INSERT INTO `emails_templates` (`id`, `code`, `name`, `subject`, `body`, `weight`, `emails_sender_id`, `status`, `created`, `modified`) VALUES
(13, 'nuevo_turno', 'Nuevo Turno', 'Peugeot - recordatorio Test Drive ', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="418" valign="top">\r\n            <img src="[%url_base%]img/newsletter/inicial/im_lateral-izq.jpg" width="42" height="418" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="[%url_base%]img/newsletter/inicial/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">[%nombre%]</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Este es un recordatorio para tu test drive</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Tu turno es el: [%turno_id%]</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="5"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#767676;font-size:14px;text-transform:uppercase;">EL [%fecha%]  de [%hora_inicio%] a [%hora_fin%]Hs en [%concesionaria%]</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="22"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e2;font-size:12px;text-transform:uppercase;">* Para realizar tu test drive debes confirmar tu reserva 10 minutos antes del horario del turno, caso contrario es cancelada</span>\r\n                </td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="418" valign="top"><img src="[%url_base%]img/newsletter/inicial/im_lateral-der.jpg" width="42" height="418" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="[%url_base%]img/newsletter/inicial/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 1, 1, 1, '2012-12-29 18:50:37', '2012-12-29 19:34:58'),
(14, 'fin_turno', 'Fin test drive', 'Peugeot - Fin Test Drive', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html xmlns="http://www.w3.org/1999/xhtml">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />\r\n<title>Peugeot - Test Drive</title>\r\n</head>\r\n\r\n<body>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td valign="top">\r\n    	<table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="42" height="258" valign="top">\r\n            <img src="[%url_base%]img/newsletter/final/im_lateral-izq.jpg" width="42" height="258" style="float:left;" />\r\n          </td>\r\n          <td width="520" valign="top" bgcolor="#e3e3e3">\r\n            <table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n              <tr>\r\n                <td width="520" height="159" valign="top">\r\n                  <img src="[%url_base%]img/newsletter/final/im_header.jpg" width="520" height="159"style="float:left;">\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:46px;">Hola [%nombre%]</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="7"></td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" valign="top" align="left">\r\n                  <span style="font-family:Arial, Helvetica, sans-serif;color:#1e1e26;font-size:20px;text-transform:uppercase;">Gracias por vivir la experiencia Peugeot</span>\r\n                </td>\r\n              </tr>\r\n              <tr>\r\n                <td width="520" height="10"></td>\r\n              </tr>\r\n            </table>\r\n          </td>\r\n          <td width="42" height="258" valign="top"><img src="[%url_base%]img/newsletter/final/im_lateral-der.jpg" width="42" height="258" style="float:left;" /></td>\r\n        </tr>\r\n      </table>\r\n      <table width="604" border="0" cellspacing="0" cellpadding="0" align="center">\r\n        <tr>\r\n          <td width="604" height="315" valign="top">\r\n            <img src="[%url_base%]img/newsletter/final/im_footer.jpg" width="604" height="315" style="float:left;">\r\n          </td>\r\n        </tr>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n\r\n</body>\r\n</html>\r\n', 2, 1, 1, '2012-12-29 19:41:02', '2012-12-29 19:50:24');

-- --------------------------------------------------------

--
-- Table structure for table `emails_templates_emails_variables`
--

CREATE TABLE IF NOT EXISTS `emails_templates_emails_variables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emails_template_id` int(11) NOT NULL,
  `emails_variable_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=56 ;

--
-- Dumping data for table `emails_templates_emails_variables`
--

INSERT INTO `emails_templates_emails_variables` (`id`, `emails_template_id`, `emails_variable_id`) VALUES
(42, 13, 1),
(43, 13, 2),
(45, 13, 4),
(46, 13, 5),
(47, 13, 6),
(50, 13, 3),
(52, 13, 7),
(54, 14, 3),
(55, 14, 7);

-- --------------------------------------------------------

--
-- Table structure for table `emails_variables`
--

CREATE TABLE IF NOT EXISTS `emails_variables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `emails_variables`
--

INSERT INTO `emails_variables` (`id`, `name`, `code`, `created`, `modified`) VALUES
(1, 'Turno', 'turno_id', '2012-07-23 19:50:35', '2012-12-29 18:52:41'),
(2, 'Fecha', 'fecha', '2012-07-28 19:32:36', '2012-12-29 18:52:55'),
(3, 'Nombre', 'nombre', '2012-07-28 19:32:54', '2012-12-29 19:41:18'),
(4, 'Hora de Inicio', 'hora_inicio', '2012-07-28 19:33:03', '2012-12-29 18:53:21'),
(5, 'Hora de fin', 'hora_fin', '2012-07-28 19:33:20', '2012-12-29 18:53:40'),
(6, 'Concesionaria', 'concesionaria', '2012-12-29 18:54:04', '2012-12-29 18:54:04'),
(7, 'URL base', 'url_base', '2012-12-29 19:22:30', '2012-12-29 19:41:24');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `title`, `native`, `alias`, `status`, `weight`, `updated`, `created`) VALUES
(1, 'English', 'English', 'eng', 1, 1, '2009-11-02 21:37:38', '2009-11-02 20:52:00');

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE IF NOT EXISTS `meta` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `meta`
--

INSERT INTO `meta` (`id`, `model`, `foreign_key`, `key`, `value`, `weight`) VALUES
(1, 'Node', 1, 'meta_keywords', 'key1, key2', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modelos`
--

CREATE TABLE IF NOT EXISTS `modelos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `modelos`
--

INSERT INTO `modelos` (`id`, `title`, `class`, `status`, `created`, `modified`) VALUES
(1, 'RCZ', 'p-rcz', 1, '2012-12-28 23:34:25', '2012-12-31 16:39:02'),
(2, '508 GT', 'p-508', 1, '2012-12-28 23:34:34', '2012-12-31 16:39:10'),
(3, '508 Feline HDI', 'p-508', 1, '2012-12-28 23:34:41', '2012-12-31 16:39:16'),
(4, '3008 Tiptronic', 'p-3008', 1, '2012-12-28 23:35:12', '2012-12-31 16:39:24'),
(5, '3008 Premium Plus Manual', 'p-3008', 1, '2012-12-28 23:35:20', '2012-12-31 16:39:28'),
(6, '5008 Allure Plus', 'p-5008', 1, '2012-12-28 23:35:28', '2012-12-31 16:39:43'),
(7, '308 CC', 'p-308cc', 1, '2012-12-28 23:35:36', '2012-12-31 16:40:01'),
(8, '308 GTI', 'p-308gti', 1, '2012-12-28 23:35:42', '2012-12-31 16:40:08'),
(9, '408 Sport', 'p-408', 1, '2012-12-28 23:35:49', '2012-12-31 16:40:20'),
(10, '408 Feline Nafta', 'p-408', 1, '2012-12-28 23:35:59', '2012-12-31 16:40:29'),
(11, '308 Sport', 'p-308', 1, '2012-12-28 23:36:07', '2012-12-31 16:40:42'),
(12, '308 Feline HDI', 'p-308', 1, '2012-12-28 23:36:13', '2012-12-31 16:40:45'),
(13, '308 Allure 1.6 C/ Nav', 'p-308', 1, '2012-12-28 23:36:24', '2012-12-31 16:40:48');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `alias`, `created`, `updated`) VALUES
(1, 'Admin', 'admin', '2009-04-05 00:10:34', '2009-04-05 00:10:34'),
(2, 'Promotora', 'promotora', '2009-04-05 00:10:50', '2012-12-19 19:54:19'),
(3, 'Public', 'public', '2009-04-05 00:12:38', '2009-04-07 01:41:45');

-- --------------------------------------------------------

--
-- Table structure for table `roles_users`
--

CREATE TABLE IF NOT EXISTS `roles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `granted_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pk_role_users` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `schema_migrations`
--

CREATE TABLE IF NOT EXISTS `schema_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `schema_migrations`
--

INSERT INTO `schema_migrations` (`id`, `class`, `type`, `created`) VALUES
(1, 'InitMigrations', 'Migrations', '2012-12-09 19:58:21'),
(2, 'ConvertVersionToClassNames', 'Migrations', '2012-12-09 19:58:21'),
(3, 'IncreaseClassNameLength', 'Migrations', '2012-12-09 19:58:22'),
(4, 'FirstMigrationSettings', 'Settings', '2012-12-09 19:58:22'),
(5, 'FirstMigrationAcl', 'Acl', '2012-12-09 19:58:22'),
(6, 'FirstMigrationBlocks', 'Blocks', '2012-12-09 19:58:23'),
(7, 'FirstMigrationComments', 'Comments', '2012-12-09 19:58:23'),
(8, 'FirstMigrationContacts', 'Contacts', '2012-12-09 19:58:23'),
(9, 'FirstMigrationMenus', 'Menus', '2012-12-09 19:58:23'),
(10, 'FirstMigrationMeta', 'Meta', '2012-12-09 19:58:23'),
(11, 'FirstMigrationNodes', 'Nodes', '2012-12-09 19:58:23'),
(12, 'FirstMigrationTaxonomy', 'Taxonomy', '2012-12-09 19:58:24'),
(13, 'FirstMigrationUsers', 'Users', '2012-12-09 19:58:24');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=39 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `title`, `description`, `input_type`, `editable`, `weight`, `params`) VALUES
(6, 'Site.title', 'Peugeot', '', '', '', 1, 1, ''),
(7, 'Site.tagline', 'Peugeot', '', '', 'textarea', 1, 2, ''),
(8, 'Site.email', 'you@your-site.com', '', '', '', 1, 3, ''),
(9, 'Site.status', '1', '', '', 'checkbox', 1, 5, ''),
(12, 'Meta.robots', 'index, follow', '', '', '', 1, 6, ''),
(13, 'Meta.keywords', 'Peugeot', '', '', 'textarea', 1, 7, ''),
(14, 'Meta.description', 'Peugeot', '', '', 'textarea', 1, 8, ''),
(20, 'Site.theme', '', '', '', '', 0, 9, ''),
(21, 'Site.feed_url', '', '', '', '', 0, 10, ''),
(26, 'Site.locale', 'eng', '', '', 'text', 0, 11, ''),
(29, 'Site.timezone', '0', '', 'zero (0) for GMT', '', 1, 4, ''),
(32, 'Hook.bootstraps', 'Settings,Users,General,Emails,Meta', '', '', '', 0, 12, ''),
(38, 'Croogo.version', '1.4.3\n', '', '', '', 0, 13, '');

-- --------------------------------------------------------

--
-- Table structure for table `turnos`
--

CREATE TABLE IF NOT EXISTS `turnos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sexo` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `licencia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vencimiento` date DEFAULT NULL,
  `provincia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `localidad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nacimiento` date DEFAULT NULL,
  `auto_id` int(11) NOT NULL,
  `concesionaria_id` int(11) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `fecha` date NOT NULL,
  `finalizado` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=757 ;

--
-- Dumping data for table `turnos`
--

INSERT INTO `turnos` (`id`, `nombre`, `email`, `sexo`, `licencia`, `vencimiento`, `provincia`, `localidad`, `telefono`, `nacimiento`, `auto_id`, `concesionaria_id`, `hora_inicio`, `hora_fin`, `fecha`, `finalizado`, `status`, `created`, `modified`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(31, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2012-12-27', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(41, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(48, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(52, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(53, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(55, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(56, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(61, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(62, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(63, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(64, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(66, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(68, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(71, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2012-12-28', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(73, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(74, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(76, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(77, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(78, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(79, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(80, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(81, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(82, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(84, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(85, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(86, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(87, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(89, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(91, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(93, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(95, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(97, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(98, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(99, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(101, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(103, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(105, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(107, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2012-12-29', 0, 0, '2012-12-26 21:01:48', '2012-12-26 21:01:48'),
(109, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:00:00', '09:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:20:00', '09:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(111, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:40:00', '10:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:00:00', '10:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(113, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:20:00', '10:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(114, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:40:00', '11:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:00:00', '11:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(116, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:20:00', '11:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(117, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:40:00', '12:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(118, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:00:00', '12:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:20:00', '12:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(120, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:40:00', '13:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(121, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:00:00', '13:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:20:00', '13:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(123, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:40:00', '14:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(124, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:00:00', '14:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:20:00', '14:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(126, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:40:00', '15:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(127, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:00:00', '15:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:20:00', '15:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(129, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:40:00', '16:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(130, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:00:00', '16:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(131, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:20:00', '16:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:40:00', '17:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(133, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:00:00', '17:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(134, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:20:00', '17:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(135, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:40:00', '18:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(136, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:00:00', '18:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(137, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:20:00', '18:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(138, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:40:00', '19:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(139, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:00:00', '19:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(140, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:20:00', '19:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(141, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:40:00', '20:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(142, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:00:00', '20:20:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(143, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:20:00', '20:40:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(144, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:40:00', '21:00:00', '2012-12-27', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(145, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:00:00', '09:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:20:00', '09:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(147, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:40:00', '10:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(148, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:00:00', '10:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:20:00', '10:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(150, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:40:00', '11:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(151, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:00:00', '11:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:20:00', '11:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(153, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:40:00', '12:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(154, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:00:00', '12:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:20:00', '12:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(156, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:40:00', '13:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(157, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:00:00', '13:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:20:00', '13:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(159, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:40:00', '14:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(160, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:00:00', '14:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:20:00', '14:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(162, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:40:00', '15:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(163, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:00:00', '15:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:20:00', '15:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(165, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:40:00', '16:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(166, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:00:00', '16:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(167, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:20:00', '16:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:40:00', '17:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(169, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:00:00', '17:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(170, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:20:00', '17:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(171, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:40:00', '18:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:00:00', '18:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(173, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:20:00', '18:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(174, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:40:00', '19:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(175, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:00:00', '19:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:20:00', '19:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(177, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:40:00', '20:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(178, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:00:00', '20:20:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:20:00', '20:40:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(180, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:40:00', '21:00:00', '2012-12-28', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(181, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:00:00', '09:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:20:00', '09:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(183, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:40:00', '10:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(184, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:00:00', '10:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:20:00', '10:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(186, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:40:00', '11:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(187, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:00:00', '11:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(188, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:20:00', '11:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(189, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:40:00', '12:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(190, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:00:00', '12:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(191, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:20:00', '12:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(192, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:40:00', '13:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(193, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:00:00', '13:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(194, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:20:00', '13:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(195, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:40:00', '14:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(196, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:00:00', '14:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(197, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:20:00', '14:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(198, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:40:00', '15:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(199, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:00:00', '15:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(200, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:20:00', '15:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(201, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:40:00', '16:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(202, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:00:00', '16:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(203, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:20:00', '16:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(204, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:40:00', '17:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(205, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:00:00', '17:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(206, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:20:00', '17:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(207, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:40:00', '18:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(208, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:00:00', '18:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(209, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:20:00', '18:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(210, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:40:00', '19:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(211, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:00:00', '19:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(212, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:20:00', '19:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(213, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:40:00', '20:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(214, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:00:00', '20:20:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(215, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:20:00', '20:40:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(216, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:40:00', '21:00:00', '2012-12-29', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(217, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:00:00', '09:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(218, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:20:00', '09:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(219, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '09:40:00', '10:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(220, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:00:00', '10:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(221, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:20:00', '10:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(222, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '10:40:00', '11:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(223, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:00:00', '11:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(224, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:20:00', '11:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(225, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '11:40:00', '12:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(226, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:00:00', '12:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(227, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:20:00', '12:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(228, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '12:40:00', '13:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(229, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:00:00', '13:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(230, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:20:00', '13:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(231, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '13:40:00', '14:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(232, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:00:00', '14:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(233, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:20:00', '14:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(234, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '14:40:00', '15:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(235, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:00:00', '15:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(236, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:20:00', '15:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(237, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '15:40:00', '16:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(238, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:00:00', '16:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(239, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:20:00', '16:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(240, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '16:40:00', '17:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(241, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:00:00', '17:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(242, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:20:00', '17:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(243, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '17:40:00', '18:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(244, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:00:00', '18:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(245, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:20:00', '18:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(246, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '18:40:00', '19:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(247, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:00:00', '19:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(248, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:20:00', '19:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(249, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '19:40:00', '20:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(250, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:00:00', '20:20:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(251, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:20:00', '20:40:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(252, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 1, '20:40:00', '21:00:00', '2012-12-30', 0, 0, '2012-12-27 23:23:57', '2012-12-27 23:23:57'),
(253, 'lalalala', 'asdfasdf@asdfasdf.com', 'M', 'asdkjfhsahfi', '2012-12-28', 'Buenos Aires', 'lalala', '32453245435', '1994-12-29', 3, 2, '09:00:00', '09:20:00', '2012-12-27', 0, 1, '2012-12-27 23:24:14', '2012-12-29 18:01:47'),
(254, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:20:00', '09:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(255, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:40:00', '10:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(256, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:00:00', '10:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(257, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:20:00', '10:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(258, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:40:00', '11:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(259, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:00:00', '11:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(260, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:20:00', '11:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(261, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:40:00', '12:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(262, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:00:00', '12:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(263, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:20:00', '12:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(264, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:40:00', '13:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(265, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:00:00', '13:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(266, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:20:00', '13:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(267, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:40:00', '14:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(268, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:00:00', '14:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(269, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:20:00', '14:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(270, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:40:00', '15:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(271, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:00:00', '15:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:20:00', '15:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(273, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:40:00', '16:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(274, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:00:00', '16:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(275, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:20:00', '16:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(276, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:40:00', '17:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(277, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:00:00', '17:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:20:00', '17:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(279, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:40:00', '18:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(280, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:00:00', '18:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(281, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:20:00', '18:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(282, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:40:00', '19:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(283, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:00:00', '19:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(284, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:20:00', '19:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(285, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:40:00', '20:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(286, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:00:00', '20:20:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(287, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:20:00', '20:40:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(288, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:40:00', '21:00:00', '2012-12-27', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:00:00', '09:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(290, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:20:00', '09:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(291, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:40:00', '10:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(292, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:00:00', '10:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(293, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:20:00', '10:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(294, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:40:00', '11:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(295, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:00:00', '11:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(296, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:20:00', '11:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(297, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:40:00', '12:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(298, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:00:00', '12:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(299, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:20:00', '12:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(300, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:40:00', '13:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(301, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:00:00', '13:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:20:00', '13:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(303, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:40:00', '14:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(304, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:00:00', '14:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(305, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:20:00', '14:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(306, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:40:00', '15:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(307, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:00:00', '15:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(308, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:20:00', '15:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(309, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:40:00', '16:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(310, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:00:00', '16:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:20:00', '16:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(312, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:40:00', '17:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:00:00', '17:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(314, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:20:00', '17:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(315, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:40:00', '18:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(316, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:00:00', '18:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:20:00', '18:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(318, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:40:00', '19:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(319, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:00:00', '19:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(320, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:20:00', '19:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(321, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:40:00', '20:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14');
INSERT INTO `turnos` (`id`, `nombre`, `email`, `sexo`, `licencia`, `vencimiento`, `provincia`, `localidad`, `telefono`, `nacimiento`, `auto_id`, `concesionaria_id`, `hora_inicio`, `hora_fin`, `fecha`, `finalizado`, `status`, `created`, `modified`) VALUES
(322, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:00:00', '20:20:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:20:00', '20:40:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(324, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:40:00', '21:00:00', '2012-12-28', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(325, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:00:00', '09:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:20:00', '09:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(327, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:40:00', '10:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(328, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:00:00', '10:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(329, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:20:00', '10:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(330, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:40:00', '11:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(331, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:00:00', '11:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:20:00', '11:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(333, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:40:00', '12:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(334, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:00:00', '12:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(335, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:20:00', '12:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(336, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:40:00', '13:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:00:00', '13:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(338, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:20:00', '13:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(339, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:40:00', '14:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(340, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:00:00', '14:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(341, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:20:00', '14:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(342, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:40:00', '15:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(343, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:00:00', '15:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(344, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:20:00', '15:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:40:00', '16:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(346, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:00:00', '16:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(347, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:20:00', '16:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(348, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:40:00', '17:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(349, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:00:00', '17:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(350, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:20:00', '17:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(351, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:40:00', '18:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(352, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:00:00', '18:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(353, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:20:00', '18:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(354, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:40:00', '19:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(355, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:00:00', '19:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(356, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:20:00', '19:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(357, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:40:00', '20:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(358, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:00:00', '20:20:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(359, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:20:00', '20:40:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(360, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:40:00', '21:00:00', '2012-12-29', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(361, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:00:00', '09:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(362, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:20:00', '09:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(363, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '09:40:00', '10:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(364, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:00:00', '10:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(365, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:20:00', '10:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(366, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '10:40:00', '11:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(367, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:00:00', '11:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(368, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:20:00', '11:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(369, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '11:40:00', '12:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(370, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:00:00', '12:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(371, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:20:00', '12:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(372, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '12:40:00', '13:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(373, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:00:00', '13:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(374, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:20:00', '13:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(375, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '13:40:00', '14:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(376, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:00:00', '14:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(377, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:20:00', '14:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(378, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '14:40:00', '15:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(379, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:00:00', '15:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(380, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:20:00', '15:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(381, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '15:40:00', '16:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(382, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:00:00', '16:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(383, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:20:00', '16:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(384, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '16:40:00', '17:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(385, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:00:00', '17:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(386, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:20:00', '17:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(387, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '17:40:00', '18:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(388, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:00:00', '18:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(389, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:20:00', '18:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(390, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '18:40:00', '19:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(391, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:00:00', '19:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(392, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:20:00', '19:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(393, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '19:40:00', '20:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(394, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:00:00', '20:20:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(395, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:20:00', '20:40:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(396, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 2, '20:40:00', '21:00:00', '2012-12-30', 0, 0, '2012-12-27 23:24:14', '2012-12-27 23:24:14'),
(397, 'pru', 'regueira@gmail.com', 'M', 'dsfsadfadsf', '2012-12-29', 'Capital Federal', 'dfaasdfasdf', '14354354gf', '1994-12-29', 1, 1, '09:00:00', '09:20:00', '2013-01-01', 1, 1, '2012-12-29 00:55:43', '2012-12-29 19:46:17'),
(398, 'juancito', 'regueira@gmail.com', 'M', '12343534657', '2012-12-29', 'Capital Federal', 'asgagsdfg', '24563456436', '1994-12-29', 1, 1, '09:20:00', '09:40:00', '2013-01-01', 1, 1, '2012-12-29 00:55:43', '2012-12-31 17:58:38'),
(399, 'dfjlkdsajfñlj', 'regueira@gmail.com', 'M', 'asdfasdfasdf', '2012-12-29', 'Catamarca', 'asdfasdf', 'asdasfdasfd', '1994-12-29', 1, 1, '09:40:00', '10:00:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:03:52'),
(400, 'ooooo', 'regueira@gmail.com', 'M', 'asdf', '2012-12-29', 'Capital Federal', 'asdfasdfsadf', 'asdfasfasdf', '1994-12-29', 1, 1, '10:00:00', '10:20:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:04:49'),
(401, 'asdfasdf', 'regueira@gmail.com', 'M', 'asdfasdfasfd', '2012-12-29', 'Catamarca', 'asdfasdf', 'asdfasfd', '1994-12-29', 1, 1, '10:20:00', '10:40:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:06:01'),
(402, 'juancito lopez', 'regueira@gmail.com', 'M', '143524352345', '2012-12-29', 'Capital Federal', 'asfasdf', '43654543262', '1994-12-29', 1, 1, '10:40:00', '11:00:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:11:16'),
(403, 'Sebastian Regueira', 'regueira@gmail.com', 'M', '19837983', '2012-12-29', 'Capital Federal', 'asdfasdf', 'adsfasdfsdf', '1994-12-29', 1, 1, '11:00:00', '11:20:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:14:11'),
(404, 'juan lopez', 'regueira@gmail.com', 'M', 'asdfasdf', '2012-12-29', 'Capital Federal', 'asdfasdf', 'asfdasdf', '1994-12-29', 1, 1, '11:20:00', '11:40:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:26:18'),
(405, 'Juancito Lopez', 'regueira@gmail.com', 'M', 'asdfasdfasdf', '2012-12-29', 'Catamarca', 'adsfasdf', 'fasdfasdfasfd', '1994-12-29', 1, 1, '11:40:00', '12:00:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:31:23'),
(406, 'Sebastian Regueira', 'regueira@gmail.com', 'M', 'asdfasdfasdf', '2012-12-29', 'Chaco', 'adsafasdf', 'asdfasdf', '1994-12-29', 1, 1, '12:00:00', '12:20:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-29 19:35:24'),
(407, 'seeeeebbaaaaa', 'regueira@gmail.com', 'M', '345643563456', '2012-12-31', 'Catamarca', 'qetrqwerwer', '364567657567', '1994-12-31', 1, 1, '12:20:00', '12:40:00', '2013-01-01', 0, 1, '2012-12-29 00:55:43', '2012-12-31 17:21:02'),
(408, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(409, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(410, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(411, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(412, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(413, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(414, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(415, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(416, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(417, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(418, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(419, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(420, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(421, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(422, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(423, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(424, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(425, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(426, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(427, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(428, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(429, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(430, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(431, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(432, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-01', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(433, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(434, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(435, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(436, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(437, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(438, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(439, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(440, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(441, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(442, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(443, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(444, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(445, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(446, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(447, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(448, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(449, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(450, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(451, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(452, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(453, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(454, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(455, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(457, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(458, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(459, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(460, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(461, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(462, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(463, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(464, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(465, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(466, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(467, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(468, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-02', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(469, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(470, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(471, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(472, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(473, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(475, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(476, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(477, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(478, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(479, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(480, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(481, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(482, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(483, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(484, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(485, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(486, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(487, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(488, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(489, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(490, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(491, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(492, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(493, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(494, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(495, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(496, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(497, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(498, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(499, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(501, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(502, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(503, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(504, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-03', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(505, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(506, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(507, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(508, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(509, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(510, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(511, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(512, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(513, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(514, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(515, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(516, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(517, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(518, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(519, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(520, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(521, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(522, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(523, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(524, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(525, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(526, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(527, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(528, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(529, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(530, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(531, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(532, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(533, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(534, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(535, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(536, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(537, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(538, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(539, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-04', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(541, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(543, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(544, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(545, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(546, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(547, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(548, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(549, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(550, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(551, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(552, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(553, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(554, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(555, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(556, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(557, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(558, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(559, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(560, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(561, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(562, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(563, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(564, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(565, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(566, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(567, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(568, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(569, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(570, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(571, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(572, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(573, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(574, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(575, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(576, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-05', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(577, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(578, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(579, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(580, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(581, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(582, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(583, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(584, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(585, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(586, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(588, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(589, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(590, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(591, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(594, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(595, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(596, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(597, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(598, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(599, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(600, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(601, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(602, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(603, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(604, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(605, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(606, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(607, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(608, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(609, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(610, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(611, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(612, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-06', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(613, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(614, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(615, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(616, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(617, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(618, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(619, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(620, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(621, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(622, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(623, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(624, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(625, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(626, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(627, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(628, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(629, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(630, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(631, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(632, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(633, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(634, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(635, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(636, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43');
INSERT INTO `turnos` (`id`, `nombre`, `email`, `sexo`, `licencia`, `vencimiento`, `provincia`, `localidad`, `telefono`, `nacimiento`, `auto_id`, `concesionaria_id`, `hora_inicio`, `hora_fin`, `fecha`, `finalizado`, `status`, `created`, `modified`) VALUES
(637, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(638, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(639, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(640, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(641, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(642, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(643, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(644, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(645, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(646, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(647, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(648, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-07', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(649, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(650, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(651, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(652, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(653, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(654, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(655, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(656, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(657, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(658, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(659, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(660, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(661, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(662, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(663, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(664, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(665, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(666, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(668, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(669, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(670, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(671, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(672, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(674, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(675, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(676, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(677, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(678, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(680, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(681, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(682, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(684, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-08', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(685, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(686, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(687, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(688, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(689, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(690, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(691, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(692, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(693, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(694, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(695, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(696, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(697, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(698, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(699, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(700, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(701, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(703, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(704, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(705, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(706, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(707, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(708, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(709, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(710, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(711, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(712, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(713, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(714, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(715, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(716, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(717, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(718, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(719, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-09', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(721, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:00:00', '09:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(722, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:20:00', '09:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(723, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '09:40:00', '10:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(724, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:00:00', '10:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(725, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:20:00', '10:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(726, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '10:40:00', '11:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(727, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:00:00', '11:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(728, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:20:00', '11:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(729, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '11:40:00', '12:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(730, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:00:00', '12:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(731, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:20:00', '12:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(732, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '12:40:00', '13:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(733, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:00:00', '13:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(734, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:20:00', '13:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(735, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '13:40:00', '14:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(736, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:00:00', '14:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(737, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:20:00', '14:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(738, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '14:40:00', '15:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(739, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:00:00', '15:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(740, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:20:00', '15:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(741, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '15:40:00', '16:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(742, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:00:00', '16:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(743, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:20:00', '16:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(744, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '16:40:00', '17:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(745, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:00:00', '17:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(746, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:20:00', '17:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(747, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '17:40:00', '18:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(748, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:00:00', '18:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(749, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:20:00', '18:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(750, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '18:40:00', '19:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(751, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:00:00', '19:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(752, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:20:00', '19:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(753, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '19:40:00', '20:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(754, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:00:00', '20:20:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(755, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:20:00', '20:40:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43'),
(756, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, '20:40:00', '21:00:00', '2013-01-10', 0, 0, '2012-12-29 00:55:43', '2012-12-29 00:55:43');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `timezone` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `username`, `password`, `name`, `email`, `website`, `activation_key`, `image`, `bio`, `timezone`, `status`, `updated`, `created`) VALUES
(1, 1, 'admin', '7d882148eb676e4f5f56116a61d4ea48195d0c61', 'admin', '', NULL, '49fcf6320354a8081d3eecb52b9e1551', NULL, NULL, '0', 1, '2012-12-09 19:59:43', '2012-12-09 19:59:43'),
(2, 2, 'promotora', '47ff16bd0fce0bafbbad4faa9449913cb853ce15', 'promotora', 'a@a.com', '', 'c929d1ec8dddc76e2ada5eeccb1191e3', NULL, NULL, '0', 1, '2012-12-31 17:46:23', '2012-12-31 17:46:14');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
